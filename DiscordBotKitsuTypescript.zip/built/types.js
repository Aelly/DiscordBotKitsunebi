"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TYPES = void 0;
exports.TYPES = {
    Token: Symbol("Token"),
    Prefix: Symbol("Prefix"),
    EmbedColor: Symbol("EmbedColor"),
    LodestoneApiKey: Symbol("LodestoneApiKey"),
    FFLogsClientID: Symbol("FFLogsClientID"),
    FFLogsClientSecret: Symbol("FFLogsClientSecret"),
    Bot: Symbol("Bot"),
    Client: Symbol("Client"),
    MessageResponder: Symbol("MessageResponder"),
    LodestoneAPI: Symbol("LodestoneAPI"),
    FFLogApi: Symbol("FFLogApi"),
    FFLogsHttpAuth: Symbol("FFLogsHttpAuth"),
};
//# sourceMappingURL=types.js.map