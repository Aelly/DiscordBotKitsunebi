"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
require("reflect-metadata");
const ffxiv_lodestone_api_calls_1 = require("./services/Api/FFXIVLodestone/Calls/ffxiv-lodestone-api-calls");
const inversify_1 = require("inversify");
const types_1 = require("./types");
const bot_1 = require("./bot");
const discord_js_1 = require("discord.js");
const message_responder_1 = require("./services/message-responder");
const ffxiv_log_api_graphql_1 = __importDefault(require("./services/Api/FFXIVLog/Calls/ffxiv-log-api-graphql"));
const ffxiv_log_api_rest_1 = __importDefault(require("./services/Api/FFXIVLog/Calls/ffxiv-log-api-rest"));
let container = new inversify_1.Container();
container.bind(types_1.TYPES.Token).toConstantValue(process.env.TOKEN);
container.bind(types_1.TYPES.Prefix).toConstantValue(process.env.PREFIX);
container.bind(types_1.TYPES.EmbedColor).toConstantValue(process.env.EMBED_COLOR);
container.bind(types_1.TYPES.LodestoneApiKey).toConstantValue(process.env.LODESTONE_API_KEY);
container.bind(types_1.TYPES.FFLogsClientID).toConstantValue(process.env.FFLOGS_CLIEND_ID);
container.bind(types_1.TYPES.FFLogsClientSecret).toConstantValue(process.env.FFLOGS_CLIENT_SECRET);
container.bind(types_1.TYPES.Bot).to(bot_1.Bot).inSingletonScope();
container.bind(types_1.TYPES.Client).toConstantValue(new discord_js_1.Client());
container.bind(types_1.TYPES.MessageResponder).to(message_responder_1.MessageResponder).inSingletonScope();
container.bind(types_1.TYPES.LodestoneAPI).to(ffxiv_lodestone_api_calls_1.FFXIVLodestoneAPICalls).inSingletonScope();
container.bind(types_1.TYPES.FFLogApi).to(ffxiv_log_api_graphql_1.default).inSingletonScope();
container.bind(types_1.TYPES.FFLogsHttpAuth).to(ffxiv_log_api_rest_1.default).inSingletonScope();
exports.default = container;
//# sourceMappingURL=inversify.config.js.map