"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FFXIVLogsAPIUtils = void 0;
const discord_js_1 = require("discord.js");
const types_1 = require("./../../../types");
const inversify_config_1 = __importDefault(require("../../../inversify.config"));
var AsciiTable = require("ascii-table");
class FFXIVLogsAPIUtils {
    static getLogs(characterName) {
        return __awaiter(this, void 0, void 0, function* () {
            const ffLogsAPI = inversify_config_1.default.get(types_1.TYPES.FFLogApi);
            const res = yield ffLogsAPI.getLogs(characterName);
            if (res == null)
                return "Erreur de communication avec FFLogs";
            else if (res.characterData.character == null)
                return "Je n'ai pas trouvé de personnage à ce nom";
            let messageEmbed = new discord_js_1.MessageEmbed().setTitle(characterName);
            FFXIVLogsAPIUtils.addFieldForZonRanking(res.characterData.character.Trials1, messageEmbed, "Trials I (Extreme)");
            FFXIVLogsAPIUtils.addFieldForZonRanking(res.characterData.character.Trials2, messageEmbed, "Trials II (Extreme)");
            FFXIVLogsAPIUtils.addFieldForZonRanking(res.characterData.character.Trials3, messageEmbed, "Trials III (Extreme)");
            FFXIVLogsAPIUtils.addFieldForZonRanking(res.characterData.character.EdensGate, messageEmbed, "Eden's gate");
            FFXIVLogsAPIUtils.addFieldForZonRanking(res.characterData.character.EdensVerse, messageEmbed, "Eden's verse");
            FFXIVLogsAPIUtils.addFieldForZonRanking(res.characterData.character.EdensPromise, messageEmbed, "Eden's promise");
            FFXIVLogsAPIUtils.addFieldForZonRanking(res.characterData.character.UltimateSB, messageEmbed, "Ultimate Stormblood");
            FFXIVLogsAPIUtils.addFieldForZonRanking(res.characterData.character.UltimateShb, messageEmbed, "Ultimage Shadowbringer");
            return messageEmbed;
        });
    }
    static addFieldForZonRanking(zoneRanking, embedToAddTo, zoneTitle) {
        const table = new AsciiTable();
        let lineAdded = false;
        for (const ranking of zoneRanking.rankings) {
            const name = ranking.encounter.name;
            const percent = Math.floor(ranking.rankPercent);
            const bestSpec = ranking.bestSpec;
            const bestAmount = Math.floor(ranking.bestAmount);
            if (bestAmount != 0) {
                table.addRow(name, percent, bestSpec, bestAmount);
                lineAdded = true;
            }
        }
        if (lineAdded)
            embedToAddTo.addField(zoneTitle, "```" + `${table.toString()}` + "```", false);
    }
}
exports.FFXIVLogsAPIUtils = FFXIVLogsAPIUtils;
//# sourceMappingURL=ffxiv-log-api-utils.js.map