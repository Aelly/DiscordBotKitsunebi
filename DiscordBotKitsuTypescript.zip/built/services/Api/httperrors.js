"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toName = void 0;
const http_1 = require("http");
class HttpError extends Error {
    constructor(code, message) {
        super(message || http_1.STATUS_CODES[code]);
        this.name = toName(code);
        this.statusCode = code;
    }
}
exports.default = HttpError;
function toName(code) {
    const suffix = (code / 100 | 0) === 4 || (code / 100 | 0) === 5 ? 'error' : '';
    return String(http_1.STATUS_CODES[code]).replace(/error$/i, '');
}
exports.toName = toName;
//# sourceMappingURL=httperrors.js.map