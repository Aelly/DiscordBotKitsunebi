"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __asyncValues = (this && this.__asyncValues) || function (o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HttpMethod = void 0;
const inversify_1 = require("inversify");
const undici_1 = require("undici");
const httperrors_1 = __importDefault(require("./httperrors"));
var HttpMethod;
(function (HttpMethod) {
    HttpMethod["Get"] = "GET";
    HttpMethod["Post"] = "POST";
})(HttpMethod = exports.HttpMethod || (exports.HttpMethod = {}));
let RestBehavior = class RestBehavior {
    constructor(url, options = {}) {
        this.pool = new undici_1.Pool(url, Object.assign({ keepAliveTimeout: 1000, headersTimeout: 0, bodyTimeout: 0, pipelining: 0, connections: 100 }, options));
    }
    request(method, path, req, headers) {
        var e_1, _a;
        return __awaiter(this, void 0, void 0, function* () {
            const options = {
                path,
                method,
                headers: Object.assign({ "Content-Type": "application/json" }, (headers || {})),
            };
            if (method === HttpMethod.Post && req) {
                options.body = JSON.stringify(req);
            }
            const { statusCode, body } = yield this.pool.request(options);
            let buffer = "";
            try {
                body.setEncoding("utf8");
                try {
                    for (var body_1 = __asyncValues(body), body_1_1; body_1_1 = yield body_1.next(), !body_1_1.done;) {
                        const data = body_1_1.value;
                        buffer = buffer.concat(data);
                    }
                }
                catch (e_1_1) { e_1 = { error: e_1_1 }; }
                finally {
                    try {
                        if (body_1_1 && !body_1_1.done && (_a = body_1.return)) yield _a.call(body_1);
                    }
                    finally { if (e_1) throw e_1.error; }
                }
            }
            catch (err) {
                body.destroy();
                throw err;
            }
            let response;
            try {
                response = JSON.parse(buffer);
            }
            catch (e) {
                response = buffer.toString();
                if (response.length === 0)
                    response = undefined;
            }
            if (statusCode >= 300) {
                throw new httperrors_1.default(statusCode.toString(), response);
            }
            return response;
        });
    }
    getHttp(path, headers) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                return yield this.request(HttpMethod.Get, path, {}, headers);
            }
            catch (e) {
                return null;
            }
        });
    }
    postHttp(path, req, headers) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                return yield this.request(HttpMethod.Post, path, req, headers);
            }
            catch (e) {
                return null;
            }
        });
    }
};
RestBehavior = __decorate([
    inversify_1.injectable(),
    __param(0, inversify_1.unmanaged()), __param(1, inversify_1.unmanaged()),
    __metadata("design:paramtypes", [String, Object])
], RestBehavior);
exports.default = RestBehavior;
//# sourceMappingURL=restBehavior.js.map