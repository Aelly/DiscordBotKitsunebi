"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlanningHandler = void 0;
const planning_1 = require("./../../class/ModifiableMessage/planning");
const stringUtils_1 = __importDefault(require("../../Utils/stringUtils"));
const types_1 = require("../../types");
const inversify_config_1 = __importDefault(require("../../inversify.config"));
class PlanningHandler {
    constructor() {
        this.commandName = "planning";
    }
    detectIfType(message) {
        return stringUtils_1.default.getCommandName(message.content) == this.commandName;
    }
    sendResponse(message) {
        return __awaiter(this, void 0, void 0, function* () {
            let bot = inversify_config_1.default.get(types_1.TYPES.Bot);
            const planning = new planning_1.Planning();
            planning.message = yield message.channel.send(yield planning.constructMessageEmbed());
            bot.modifiableMessages.push(planning);
            yield planning.addReaction();
        });
    }
}
exports.PlanningHandler = PlanningHandler;
//# sourceMappingURL=planning-handler.js.map