"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HelpHandler = void 0;
const stringUtils_1 = __importDefault(require("../../Utils/stringUtils"));
class HelpHandler {
    constructor() {
        this.commandName = "help";
    }
    detectIfType(message) {
        return stringUtils_1.default.getCommandName(message.content) == this.commandName;
    }
    sendResponse(message) {
        let response = "\n";
        response += "- !notice [Titre] - [Description]\n";
        response += "- !event [Titre] - [Description]\n";
        response += "- !planning\n";
        response += "- !clear [Nb message à supprimer]\n";
        response += "- !rand\n";
        response += "- !portrait [Nom du personnage]\n";
        response += "- !character [Nom du personnage]\n";
        response += "- !card [Nom du personnage]\n";
        response += "- !parse [Nom du personnage]\n";
        message.reply(response);
    }
}
exports.HelpHandler = HelpHandler;
//# sourceMappingURL=help-handler.js.map